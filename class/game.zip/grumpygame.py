import pygame
from pygame.locals import *
import random

class enemy:
    def __init__(self):
        self.type = random.randint(1,10)
        if (self.type <= 6):
            self.picture = pygame.image.load('troll.png').convert()
            self.speed = 0.1
            self.damage = 10
            self.width = 100
            self.height = 91
        elif (self.type <= 9):
            self.picture = pygame.image.load('troll2.png').convert()
            self.speed = 0.25
            self.damage = 30
            self.width = 100
            self.height = 76
        elif (self.type == 10):
            self.picture = pygame.image.load('forever.png').convert()
            self.speed = 0.05
            self.damage = 50
            self.width = 150
            self.height = 152
        self.y = 0
        self.x = random.randint(0, 350)
        self.xdir = random.randint(-1,1)

    def draw(self, screen):
        screen.blit(self.picture, (self.x, self.y))

    def move(self):
        self.y += self.speed
        self.x += self.speed/4*self.xdir
        

    def check_collision(self,cat_x):
        if (self.y + self.height < 440) or (self.y > 500):
            return False
        else:
            if self.x < cat_x+60 and \
               self.x+self.width > cat_x:
                return True
            else:
                return False

    
pygame.init()
screen = pygame.display.set_mode((500,500))

cat_picture = pygame.image.load('cat.jpg').convert()
font = pygame.font.Font(None, 36)

health = 100000
cat_x = 200
cat_y = 440

enemy_list = []
curr_frame = 1
while health > 0:
    curr_frame += 1
    pygame.event.pump()
    keystate = pygame.key.get_pressed()

    if keystate[K_LEFT]:
        cat_x -= 0.3
    if keystate[K_RIGHT]:
        cat_x += 0.3

    if (cat_x > 440):
        cat_x = 0
    if (cat_x < 0):
        cat_x = 440

    prob = round(50000*500/curr_frame)
    if random.randint(1,prob) == 1:
        enemy_list.append(enemy())
    

    screen.fill((255,255,255))
    
    screen.blit(cat_picture, (cat_x,cat_y))
    for i in range(len(enemy_list)):
        enemy_list[i].move()
        enemy_list[i].draw(screen)
        if enemy_list[i].check_collision(cat_x):
            health -= enemy_list[i].damage
            
    pygame.draw.line(screen, (255,0,0), (490,500),(490,500-health/100000*500),10)
    pygame.display.flip()

screen.fill((255,0,0))
gameover = font.render("GAME OVER", 1, (0,0,0))
score = font.render("SCORE: " + str(len(enemy_list)) , 1, (0,0,0))
screen.blit(gameover, (180,200))
screen.blit(score, (180, 240))
pygame.display.flip()
